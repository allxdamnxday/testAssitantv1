# OpenAI Multi-Assistant Frontend

This is the frontend part of the OpenAI Multi-Assistant application, created using React.

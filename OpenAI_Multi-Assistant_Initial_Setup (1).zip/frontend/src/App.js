import React from 'react';

function App() {
  return (
    <div className='App'>
      <header className='App-header'>
        OpenAI Multi-Assistant Frontend
      </header>
    </div>
  );
}

export default App;

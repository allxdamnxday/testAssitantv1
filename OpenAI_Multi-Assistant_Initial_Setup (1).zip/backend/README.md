# OpenAI Multi-Assistant App

This application provides a user interface for interacting with multiple OpenAI assistants. The backend is written in Node.js and integrated with OpenAI's API.
